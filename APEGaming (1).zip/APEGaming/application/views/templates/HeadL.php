<!DOCTYPE html>
<html>
<title>APE Gaming</title>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/APEStyle.css');?> ">
    
</head>

<body>
    <script type="text/javascript" src="<?php echo base_url('assets/JS/GJS.js');?>"></script>
    <!--Navigation Bar -->
        <nav class="navbar navbar-default navbar-fixed-top navbar-expand-sm navbar-dark bg-dark" id="header">
            <div class="container navbar navbar-dark bg-dark navbar-expand-lg">
                <ul class="navbar-nav mr-auto">
                    
                </ul>
            </div>
        </nav>
