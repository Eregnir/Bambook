 </head>
 <body>
        <header>
		<nav>
			<ul>
				<li><a href="<?php echo site_url();?>/Intro/index">Home</a></li>
				<li><a href=“#”>Contact Us</a></li>
                                <li><a href="<?php echo site_url();?>/weather/show">Weather</a></li>
                                <li><a href="<?php echo site_url();?>/users/logout">Logout</a></li>
			</ul>
		</nav>
	</header>
