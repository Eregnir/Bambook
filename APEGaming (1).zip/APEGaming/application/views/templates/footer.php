    <footer class="bg-dark text-center text-lg-start"> APEGaming™<br>info@apegaming.com<br> © Assaf | Pearl | Elor ©</footer>
</body>

</html>